public interface JsonToObjectImpl {
    AgeForName convert(String json);
}
