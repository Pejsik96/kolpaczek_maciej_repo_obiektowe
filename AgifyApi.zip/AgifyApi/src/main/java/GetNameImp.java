public interface GetNameImp {
    String getData(String name);
}
