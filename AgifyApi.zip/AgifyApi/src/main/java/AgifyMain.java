import java.util.Scanner;

public class AgifyMain {
    public static void main(String[] args) {
        //Polimorfizm
        GetNameImp getName = new GetName();
        Scanner sc = new Scanner(System.in);
        String name = "";
        do {
            System.out.println("Podaj imię z klawiatury [!q - zakończy program]");
            name = sc.next();
            String json = getName.getData(name);
            if (json.isEmpty() || json.contains("null")) {
                System.out.println("NULL VALUE");
            } else {
                JsonToObjectImpl toObject = new JsonToObject();
                AgeForName data = toObject.convert(json);
                System.out.println(data.getName() + " ma " + data.getAge() + " lat");
            }
        } while (!name.equals("!q"));

    }
}
