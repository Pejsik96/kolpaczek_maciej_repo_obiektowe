public class JsonToObject implements JsonToObjectImpl {
    @Override
    public AgeForName convert(final String json) {
//        {"age":59,"count":106,"name":"michał"}

        String tab[] = json.split(",");

        int age = Integer.parseInt(tab[0].substring(
                tab[0].indexOf(":") + 1
        ));
        int count = Integer.parseInt(tab[1].substring(
                tab[1].indexOf(":") + 1
        ));
        String name = tab[2].substring(tab[2].indexOf(":") + 2, tab[2].length() - 2);
        return new AgeForName(age, name, count);
    }
}
