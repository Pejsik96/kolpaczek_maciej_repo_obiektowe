public class AgeForName {
    private int age;
    private String name;
    private int count;

    public AgeForName(final int age, final String name, final int count) {
        this.age = age;
        this.name = name;
        this.count = count;
    }

    public int getAge() {
        return age;
    }

    public void setAge(final int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(final int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "AgeForName{" +
                "age=" + age +
                ", name='" + name + '\'' +
                ", count=" + count +
                '}';
    }
}
