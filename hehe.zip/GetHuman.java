import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

public class GetHuman {
    public static Human get(String name) {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://api.agify.io?name=" + name))
            .build();
        
        String responseText = "";
        try {
            HttpResponse response = client.send(request, HttpResponse.BodyHandlers.ofString());
            responseText = response.body().toString();
        } catch (Exception e) {}
        
        ArrayList<String> data = new ArrayList<>();
        String [] responseSplit = responseText.split(",");
        for (String string : responseSplit) {
            data.add(string.split(":")[1]);
        }
        data.set(2, data.get(2).substring(1, data.get(2).length()-2));

        return new Human(Integer.parseInt(data.get(0)), Integer.parseInt(data.get(1)), data.get(2));
    }
}