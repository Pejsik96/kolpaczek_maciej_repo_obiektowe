public class Human {
    private String name;
    private int count, age;

    public Human(int age, int count, String name) {
        this.age = age;
        this.count = count;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getCount() {
        return count;
    }

    @Override
    public String toString() {
        return name + " is " + age + " years old (" + count + ")";
    }
}