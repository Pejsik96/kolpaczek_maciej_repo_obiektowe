import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Human> humans = new ArrayList<>();

        while (0<1) {
            Display.clear();
            Display.print("Wprowadź imię: ");

            Human h = GetHuman.get(Display.getInputLine());
            humans.add(h);
            Display.line(h.toString());

            Display.line("\nCzy chcesz wprowadzić kolejne imię? (Y/N)");
            if(Display.getInput().toLowerCase().equals("n")) {
                Display.clear();
                for (Human hum : humans) {
                    Display.line(hum.toString());
                }
                return;
            }
        }
    }
}


// ?name[]=michael&name[]=gowno